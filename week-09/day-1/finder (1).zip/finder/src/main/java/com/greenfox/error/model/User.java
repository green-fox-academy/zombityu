package com.greenfox.error.model;

/**
 * Created by aze on 25/10/17.
 */
public class User {
    private String firstName;
    private String lastName;
}
